const r=require('express').Router();const U=require('../models/User');
r.post('/add',async(req,res)=>{await U.updateOne({_id:req.body.userId},{$inc:{wallet:req.body.amount}});res.json({message:'Money added'});});
r.get('/balance/:id',async(req,res)=>{const u=await U.findById(req.params.id);res.json({wallet:u.wallet});});
module.exports=r;
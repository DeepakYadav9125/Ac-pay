const r=require('express').Router();const U=require('../models/User');
r.get('/users',async(req,res)=>{const users=await U.find();res.json(users);});
module.exports=r;
const r=require('express').Router();
const U=require('../models/User');const b=require('bcryptjs');const j=require('jsonwebtoken');
r.post('/register',async(req,res)=>{const h=await b.hash(req.body.password,10);await U.create({mobile:req.body.mobile,password:h});res.json({message:'User created'});});
r.post('/login',async(req,res)=>{const u=await U.findOne({mobile:req.body.mobile});if(!u)return res.json({message:'User not found'});const ok=await b.compare(req.body.password,u.password);if(!ok)return res.json({message:'Wrong password'});const t=j.sign({id:u._id},process.env.JWT_SECRET);res.json({message:'Login success',token:t,userId:u._id});});
module.exports=r;